﻿namespace Exercise0102
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Poker card= new Poker();
            card.GameStart();
        }
    }
}